#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
闪电检测 Python 服务入口 —— 常驻子进程，通过 stdin/stdout 交换 JSON

协议（每行一个 JSON）:
    请求:   {"id": 1, "cmd": "health_check", ...args}
    响应:   {"id": 1, "ok": true, "data": {...}}
            或 {"id": 1, "ok": false, "error": "..."}
    事件:   {"type": "progress", "task_id": "...", "current": n, "total": n,
             "hits": n, "file": "name"}          # 批量检测进度
            {"type": "log", "level": "info", "message": "..."}
            {"type": "env-progress", "line": "..."}

命令:
    health_check       环境健康状态
    decode             {path, max_size?} -> {data_url, width, height}
    decode_many        {paths:[...], max_size?} -> [{path, data_url, width, height}]
    detect             {path, prev_path?, window_paths?, params?, regions?, save_marked?,
                        function?}  function=lightning|meteor（默认 lightning）
                        -> 检测结果（含可选标记图 data_url）
    batch_detect       {task_id, files:[...], output_dir, params?, regions?,
                        prefix?, save_marked?, output_format?, parallel?, function?}
                        -> 完成后以请求 id 返回最终结果（parallel=true 时按帧多进程并行）
    video_detect       {task_id, video_path, output_dir, params?, regions?, function?,
                        prefix?, save_marked?, output_format?, frame_step?}
                        -> 流式拆帧检测，命中帧落盘，完成后以请求 id 返回
    cancel             {task_id}  取消进行中的批量任务
    quit               退出

依赖: pip install numpy opencv-python-headless rawpy
"""

from __future__ import annotations

import base64
import json
import sys
import threading
import traceback
from pathlib import Path

import cv2
import numpy as np

from lightning_detector import (
    DEFAULT_PARAMS,
    IMAGE_EXTS,
    LightningDetector,
    batch_detect,
    draw_marks,
    merge_params,
    read_image,
)

try:
    sys.stdout.reconfigure(encoding="utf-8", line_buffering=True)
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

_OUT_LOCK = threading.Lock()

# 在途批量任务线程跟踪（quit 时需等待收尾，避免 daemon 线程被进程终止）
_BATCH_LOCK = threading.Lock()
_BATCH_THREADS: set = set()


def _track_thread(t: threading.Thread) -> None:
    with _BATCH_LOCK:
        _BATCH_THREADS.add(t)


def _untrack_thread(t: threading.Thread) -> None:
    with _BATCH_LOCK:
        _BATCH_THREADS.discard(t)


def _join_batches(timeout: float = 30.0) -> None:
    """等待在途批量任务结束（最多 timeout 秒）"""
    deadline = threading.Timer(timeout, lambda: None)
    deadline.start()
    while deadline.is_alive():
        with _BATCH_LOCK:
            threads = list(_BATCH_THREADS)
        if not threads:
            break
        for t in threads:
            t.join(timeout=0.5)
    deadline.cancel()


def emit(obj: dict) -> None:
    """线程安全地写一行 JSON 到 stdout"""
    line = json.dumps(obj, ensure_ascii=False)
    with _OUT_LOCK:
        sys.stdout.write(line + "\n")
        sys.stdout.flush()


def respond(req_id, ok: bool, data=None, error: str = "") -> None:
    if ok:
        emit({"id": req_id, "ok": True, "data": data})
    else:
        emit({"id": req_id, "ok": False, "error": error})


def log(level: str, message: str) -> None:
    emit({"type": "log", "level": level, "message": message})


def _jpeg_data_url(rgb: np.ndarray, quality: int = 85) -> str:
    ok, buf = cv2.imencode(".jpg", cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR),
                           [cv2.IMWRITE_JPEG_QUALITY, quality])
    if not ok:
        raise RuntimeError("JPEG 编码失败")
    return "data:image/jpeg;base64," + base64.b64encode(buf.tobytes()).decode("ascii")


class LightningService:
    def __init__(self):
        self.cancel_events: dict = {}
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # 命令处理
    # ------------------------------------------------------------------
    def handle(self, req: dict) -> dict:
        cmd = req.get("cmd")
        handler = getattr(self, f"cmd_{cmd}", None)
        if handler is None:
            raise ValueError(f"未知指令: {cmd}")
        return handler(req)

    def cmd_health_check(self, req: dict) -> dict:
        import platform
        deps = {}
        for name, mod in (("numpy", "numpy"), ("cv2", "cv2"), ("rawpy", "rawpy"), ("PIL", "PIL")):
            try:
                m = __import__(mod)
                deps[name] = getattr(m, "__version__", "ok")
            except Exception:
                deps[name] = None
        return {
            "ok": all(v is not None for v in deps.values()),
            "python": sys.executable,
            "version": platform.python_version(),
            "platform": platform.platform(),
            "deps": deps,
            "missing": [k for k, v in deps.items() if v is None],
        }

    def cmd_decode(self, req: dict) -> dict:
        path = req["path"]
        max_size = int(req.get("max_size", 512))
        rgb = read_image(path, use_half_size=True)
        h, w = rgb.shape[:2]
        scale = min(1.0, max_size / max(h, w))
        if scale < 1.0:
            rgb = cv2.resize(rgb, (max(1, int(w * scale)), max(1, int(h * scale))),
                             interpolation=cv2.INTER_AREA)
        return {
            "data_url": _jpeg_data_url(rgb, 85),
            "width": int(rgb.shape[1]),
            "height": int(rgb.shape[0]),
        }

    def cmd_decode_many(self, req: dict) -> list:
        paths = req.get("paths") or []
        max_size = int(req.get("max_size", 160))
        out = []
        for p in paths:
            try:
                d = self.cmd_decode({"path": p, "max_size": max_size})
                out.append({"path": p, **d})
            except Exception as e:
                out.append({"path": p, "error": str(e)})
        return out

    def _detect_meteor(self, req: dict) -> dict:
        """流星检测（单帧测试）：diff 用 prev_path，window 用 window_paths"""
        from meteor_detector import MeteorDetector, merge_params as meteor_merge
        params = meteor_merge(req.get("params"))
        det = MeteorDetector(
            diff_threshold=params["diff_threshold"],
            min_area=params["min_area"],
            min_ratio=params["min_ratio"],
            max_ratio=params["max_ratio"],
            min_score=params["min_score"],
            window_size=params["window_size"],
            use_half_size=params["use_half_size"],
            no_auto_bright=params["no_auto_bright"],
        )
        res = det.analyze(
            req["path"],
            prev_path=req.get("prev_path"),
            window_paths=req.get("window_paths"),
            regions=req.get("regions") or [],
        )
        if res["hit"] and req.get("save_marked"):
            marked = draw_marks(det.read_rgb(req["path"]), res["boxes"], res["score"])
            res["marked_data_url"] = _jpeg_data_url(marked, 85)
        return res

    def cmd_detect(self, req: dict) -> dict:
        if req.get("function") == "meteor":
            return self._detect_meteor(req)
        path = req["path"]
        prev = req.get("prev_path")
        params = merge_params(req.get("params"))
        regions = req.get("regions") or []
        detector = LightningDetector(
            diff_threshold=params["diff_threshold"],
            min_bright_pixels=params["min_bright_pixels"],
            sky_ratio=params["sky_ratio"],
            color_weight=params["color_weight"],
            min_score=params["min_score"],
            min_brightness=params["min_brightness"],
            min_area=params["min_area"],
            use_half_size=params["use_half_size"],
            no_auto_bright=params["no_auto_bright"],
        )
        res = detector.analyze(path, prev_path=prev, regions=regions)
        if res["hit"] and req.get("save_marked"):
            img = detector.read(path)
            from lightning_detector import draw_marks
            marked = draw_marks(img, res["boxes"], res["score"])
            res["marked_data_url"] = _jpeg_data_url(marked, 85)
        return res

    def cmd_batch_detect(self, req: dict) -> dict:
        """在子线程中执行；完成时以请求 id 写回最终响应"""
        req_id = req.get("id")
        task_id = str(req.get("task_id") or req_id)
        cancel_event = threading.Event()
        with self._lock:
            self.cancel_events[task_id] = cancel_event

        def _run():
            _track_thread(threading.current_thread())
            try:
                def progress(cur, total, hits, name):
                    emit({
                        "type": "progress",
                        "task_id": task_id,
                        "current": cur,
                        "total": total,
                        "hits": hits,
                        "file": name,
                    })

                is_meteor = req.get("function") == "meteor"
                if is_meteor:
                    from meteor_detector import batch_detect as batch_fn
                    prefix_default = "meteor"
                else:
                    batch_fn = batch_detect
                    prefix_default = "lightning"

                result = batch_fn(
                    files=req.get("files") or [],
                    output_dir=req.get("output_dir", ""),
                    params=req.get("params"),
                    regions=req.get("regions") or [],
                    prefix=req.get("prefix", prefix_default),
                    save_marked=bool(req.get("save_marked")),
                    output_format=req.get("output_format", "orig"),
                    progress_cb=progress,
                    cancel_event=cancel_event,
                    parallel=bool(req.get("parallel", True)),
                )
                respond(req_id, True, result)
            except Exception as e:
                log("error", f"批量检测失败: {e}\n{traceback.format_exc()}")
                respond(req_id, False, error=str(e))
            finally:
                _untrack_thread(threading.current_thread())
                with self._lock:
                    self.cancel_events.pop(task_id, None)

        threading.Thread(target=_run, daemon=True, name=f"batch-{task_id}").start()
        # 不在此处响应 —— 由 _run 在完成/取消/出错时响应
        return {}
    def cmd_video_detect(self, req: dict) -> dict:
        """视频拆帧检测：流式抽帧 + 复用检测器；命中帧落盘，完成时以请求 id 写回"""
        req_id = req.get("id")
        task_id = str(req.get("task_id") or req_id)
        cancel_event = threading.Event()
        with self._lock:
            self.cancel_events[task_id] = cancel_event

        def _run():
            _track_thread(threading.current_thread())
            try:
                def progress(cur, total, hits, name):
                    emit({
                        "type": "progress",
                        "task_id": task_id,
                        "current": cur,
                        "total": total,
                        "hits": hits,
                        "file": name,
                    })

                from video_detect import video_detect
                result = video_detect(
                    video_path=req.get("video_path", ""),
                    output_dir=req.get("output_dir", ""),
                    params=req.get("params"),
                    function=req.get("function", "lightning"),
                    regions=req.get("regions") or [],
                    prefix=req.get("prefix", "frame"),
                    save_marked=bool(req.get("save_marked")),
                    output_format=req.get("output_format", "jpg"),
                    frame_step=int(req.get("frame_step", 1) or 1),
                    progress_cb=progress,
                    cancel_event=cancel_event,
                    log_cb=lambda m: log("info", m),
                )
                respond(req_id, True, result)
            except Exception as e:
                log("error", f"视频检测失败: {e}\n{traceback.format_exc()}")
                respond(req_id, False, error=str(e))
            finally:
                _untrack_thread(threading.current_thread())
                with self._lock:
                    self.cancel_events.pop(task_id, None)

        threading.Thread(target=_run, daemon=True, name=f"video-{task_id}").start()
        return {}

    def cmd_cancel(self, req: dict) -> dict:
        task_id = str(req.get("task_id", ""))
        with self._lock:
            ev = self.cancel_events.get(task_id)
        if ev is not None:
            ev.set()
            return {"cancelled": True}
        return {"cancelled": False, "note": "任务不存在或已完成"}

    def cmd_quit(self, req: dict) -> dict:
        return {"bye": True}


def main():
    service = LightningService()
    log("info", f"闪电检测服务已启动 python={sys.version.split()[0]}")
    log("info", f"工作目录: {Path.cwd()}")

    for line in sys.stdin:
        line = line.strip().lstrip("\ufeff")  # 防御 BOM
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError:
            continue
        rid = req.get("id")
        cmd = req.get("cmd", "")
        if cmd == "quit":
            respond(rid, True, {"bye": True})
            break
        try:
            data = service.handle(req)
            if cmd in ("batch_detect", "video_detect"):
                # 异步任务：主循环继续读 stdin（可接收 cancel），响应由子线程完成时写回
                continue
            respond(rid, True, data)
        except Exception as e:
            log("error", f"指令 {cmd} 失败: {e}")
            respond(rid, False, error=f"{e}", )

    # 退出前等待在途批量任务收尾（Rust 侧会先发 cancel）
    if _BATCH_THREADS:
        log("info", "等待在途批量任务收尾...")
        _join_batches(timeout=30.0)

    log("info", "服务退出")


if __name__ == "__main__":
    main()
