#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
流星/亮轨迹检测器 —— 参考《流星检测算法一流式滑动窗口》《流星检测算法二帧间差分》实现

两种模式：
  mode=diff   （帧间差分）：相邻帧绝对差分，星点缓慢移动产生"成对靠近的斑点"（近圆形，
               被长宽比过滤），流星/飞机是"突然出现的新亮线"（细长）。综合得分 =
               面积*0.3 + 长宽比*0.35 + 亮度变化*0.2 + 集中度*0.15。
  mode=window （滑动窗口）：窗口内帧取中值造底图（自动适配星点漂移），当前帧减底图只保留
               增亮部分，细长轮廓得分 = 面积 * (长宽比/10)；边界帧自动回退为帧间差分。

与闪电检测共用：多格式读取（RAW/JPEG）、归一化选区、命中框/标记图、批量驱动
（顺序/多进程并行）、取消。
"""

from __future__ import annotations

import os
from collections import deque
from concurrent.futures import CancelledError, Future, ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import cv2
import numpy as np

from lightning_detector import (
    copy_result,
    draw_marks,
    read_image,
    regions_to_mask,
    write_marked_image,
)

# ---------------------------------------------------------------------------
# 常量与参数
# ---------------------------------------------------------------------------
DEFAULT_PARAMS = {
    "mode": "diff",            # diff=帧间差分 | window=滑动窗口
    "diff_threshold": 20.0,    # 差分亮度阈值
    "min_area": 100,           # 最小轮廓面积
    "min_ratio": 3.0,          # 最小长宽比（过滤星点差分斑点）
    "max_ratio": 100.0,        # 最大长宽比（过滤单像素级噪线）
    "min_score": 0.5,          # 综合得分阈值（仅 diff 模式生效）
    "window_size": 21,         # 滑动窗口大小（奇数；仅 window 模式）
    "use_half_size": True,     # 半分辨率加速
    "no_auto_bright": True,    # 关闭 RAW 自动亮度
    # 飞机过滤（参考《飞机轨迹过滤算法》：跨帧轨迹关联，连续多帧同方向出现视为飞机）
    "aircraft_filter": False,  # 总开关
    "aircraft_max_frames": 2,  # 轨迹出现帧数超过此值视为飞机/卫星
    "aircraft_angle_tol": 20.0,  # 角度容差（度）
    "aircraft_dist_tol": 50.0,   # 位置容差（像素，检测分辨率）
    "aircraft_allow_gap": 1,     # 允许断帧数（应对飞机灯闪烁漏检）
}

_EMPTY_FEATURES = {"area": 0, "ratio": 0.0, "mean_diff": 0.0, "concentration": 0.0}


# ---------------------------------------------------------------------------
# 飞机过滤（参考《飞机轨迹过滤算法》：跨帧轨迹关联）
# ---------------------------------------------------------------------------
def _angle_diff(a1: float, a2: float) -> float:
    """两个角度（0-180°）的最小差值，考虑 180° 周期（同一直线方向）"""
    d = abs(a1 - a2) % 180
    return 180 - d if d > 90 else d


def _pt_dist(p1, p2) -> float:
    return float(np.hypot(p1[0] - p2[0], p1[1] - p2[1]))


def _match_cost(line_a: dict, line_b: dict, angle_tol: float, dist_tol: float) -> float:
    """组合代价（越小越可能是同一运动物体）"""
    return _angle_diff(line_a["angle"], line_b["angle"]) / max(angle_tol, 1e-6) \
        + _pt_dist(line_a["center"], line_b["center"]) / max(dist_tol, 1e-6)


def _same_track(line_a: dict, line_b: dict, angle_tol: float, dist_tol: float) -> bool:
    """角度相近 且 位置相近 → 判定为同一轨迹（飞机/卫星连续帧）
    位置容差随线长自适应：长轨迹（曝光时间长）帧间位移更大"""
    if _angle_diff(line_a["angle"], line_b["angle"]) > angle_tol:
        return False
    tol = dist_tol + 0.1 * min(line_a["length"], line_b["length"])
    return _pt_dist(line_a["center"], line_b["center"]) <= tol


def filter_aircraft(
    frame_lines: Sequence[Sequence[dict]],
    max_frames: int = 2,
    angle_tol: float = 20.0,
    dist_tol: float = 50.0,
    allow_gap: int = 1,
) -> set:
    """
    跨帧时序关联，过滤连续多帧同方向出现的飞机/卫星轨迹。

    frame_lines[i] = 第 i 帧检测到的所有候选线（dict，需含 center/angle/length）
    对每条线向后最多 allow_gap+1 帧找匹配（最近优先），取组合代价最小的最佳匹配
    加入已有轨迹；否则新建轨迹。轨迹出现帧数 <= max_frames 的保留（流星/单次亮线），
    超过的整条丢弃（飞机/卫星）。

    返回保留的 (帧索引, 线索引) 集合。
    """
    n = len(frame_lines)
    tracks: List[List[Tuple[int, int]]] = []
    line_to_track: Dict[Tuple[int, int], int] = {}

    for f in range(n):
        for l, line in enumerate(frame_lines[f]):
            best_tid: Optional[int] = None
            best_cost = float("inf")
            for gap in range(1, allow_gap + 2):
                pf = f - gap
                if pf < 0:
                    continue
                for pl, prev_line in enumerate(frame_lines[pf]):
                    key = (pf, pl)
                    tid = line_to_track.get(key)
                    if tid is None or not _same_track(prev_line, line, angle_tol, dist_tol):
                        continue
                    cost = _match_cost(prev_line, line, angle_tol, dist_tol)
                    if cost < best_cost:
                        best_cost = cost
                        best_tid = tid
            if best_tid is not None:
                tracks[best_tid].append((f, l))
                line_to_track[(f, l)] = best_tid
            else:
                tid = len(tracks)
                tracks.append([(f, l)])
                line_to_track[(f, l)] = tid

    keep: set = set()
    for tid, track in enumerate(tracks):
        unique_frames = len({f for f, _ in track})
        if unique_frames <= max_frames:
            for f, l in track:
                keep.add((f, l))
    return keep


def apply_aircraft_filter(
    frame_lines: Sequence[Sequence[dict]],
    params: dict,
) -> set:
    """按合并后的参数执行飞机过滤"""
    if not params.get("aircraft_filter"):
        return set()
    return filter_aircraft(
        frame_lines,
        max_frames=int(params.get("aircraft_max_frames") or 2),
        angle_tol=float(params.get("aircraft_angle_tol") or 20.0),
        dist_tol=float(params.get("aircraft_dist_tol") or 50.0),
        allow_gap=int(params.get("aircraft_allow_gap") or 1),
    )


def rebuild_from_kept(lines: Sequence[dict], keep: set, f: int) -> Optional[dict]:
    """按保留集合重建帧结果：只保留被保留的线，取其中得分最高者。
    无保留线时返回 None（该帧应被丢弃）"""
    kept = [line for li, line in enumerate(lines) if (f, li) in keep]
    if not kept:
        return None
    top = max(kept, key=lambda it: it["score"])
    return {
        "hit": True,
        "score": top["score"],
        "features": top["features"],
        "boxes": [top["box"]],
    }


def merge_params(raw: Optional[dict]) -> dict:
    """合并默认参数与用户参数"""
    params = dict(DEFAULT_PARAMS)
    if raw:
        for k, v in raw.items():
            if k in params and v is not None:
                params[k] = v
    if params["mode"] == "window":
        ws = int(params.get("window_size") or DEFAULT_PARAMS["window_size"])
        if ws % 2 == 0:
            ws += 1  # 保证奇数
        params["window_size"] = ws
    return params


# ---------------------------------------------------------------------------
# 检测器
# ---------------------------------------------------------------------------
class MeteorDetector:
    """流星/轨迹检测器 —— 灰度帧间差分 / 滑动窗口中值底图"""

    def __init__(
        self,
        diff_threshold: float = 20.0,
        min_area: int = 100,
        min_ratio: float = 3.0,
        max_ratio: float = 100.0,
        min_score: float = 0.5,
        window_size: int = 21,
        use_half_size: bool = True,
        no_auto_bright: bool = True,
        drop_border: bool = False,
        bottom_band: int = 0,
    ):
        self.diff_threshold = diff_threshold
        self.min_area = min_area
        self.min_ratio = min_ratio
        self.max_ratio = max_ratio
        self.min_score = min_score
        self.window_size = window_size if window_size % 2 == 1 else window_size + 1
        self.use_half_size = use_half_size
        self.no_auto_bright = no_auto_bright
        # 视频模式：排除紧贴画面边缘的轮廓（编码条带/字幕/黑边等伪影）
        self.drop_border = drop_border
        # 视频模式：忽略画面底部若干行的差分（底部条带伪影）
        self.bottom_band = bottom_band

    # -- 读取 ---------------------------------------------------------------
    def read_rgb(self, path) -> np.ndarray:
        return read_image(path, self.use_half_size, self.no_auto_bright)

    def read_gray(self, path) -> np.ndarray:
        """读取为 float32 灰度图（供差分/底图计算）"""
        rgb = self.read_rgb(path)
        return cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY).astype(np.float32)

    # -- 轮廓分析 ------------------------------------------------------------
    @staticmethod
    def _contour_items(
        diff_f: np.ndarray,
        thresh: np.ndarray,
        min_area: int,
        min_ratio: float,
        max_ratio: float,
        use_mean_diff: bool,
        drop_border: bool = False,
    ) -> Tuple[List[dict], float]:
        """
        从阈值图中找细长轮廓，返回 [(score, features, box), ...] 与最佳得分。
        box 为归一化 [x0,y0,x1,y1]。
        drop_border=True 时排除紧贴画面边缘的轮廓（视频条带/黑边/编码伪影）。
        """
        h, w = thresh.shape
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        items: List[dict] = []
        best = 0.0
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area < min_area:
                continue
            rect = cv2.minAreaRect(cnt)
            rw, rh = rect[1]
            if rw < 1 or rh < 1:
                continue
            ratio = max(rw, rh) / min(rw, rh)
            if ratio < min_ratio or ratio > max_ratio:
                continue

            x, y, bw, bh = cv2.boundingRect(cnt)
            if drop_border and (x <= 0 or y <= 0 or x + bw >= w or y + bh >= h):
                # 轮廓被画面边缘截断：几乎都是条带/黑边/编码伪影，不可能是完整轨迹
                continue
            box = (
                round(x / w, 4), round(y / h, 4),
                round((x + bw) / w, 4), round((y + bh) / h, 4),
            )
            # 中心点 / 角度（0-180°）/ 长度（供飞机轨迹关联用）
            cx, cy = float(rect[0][0]), float(rect[0][1])
            angle = rect[2]
            if rw < rh:
                angle = angle + 90
            angle = angle % 180
            length = max(rw, rh)
            feats = {"area": int(area), "ratio": round(float(ratio), 3),
                     "mean_diff": 0.0, "concentration": 0.0}
            if use_mean_diff:
                mask = np.zeros_like(thresh)
                cv2.drawContours(mask, [cnt], -1, 255, -1)
                mean_diff = float(np.mean(diff_f[mask > 0]))
                yy, xx = np.where(mask > 0)
                if len(yy) > 1:
                    y_std = float(np.std(yy))
                    x_std = float(np.std(xx))
                    concentration = 1.0 - min((y_std / h + x_std / w) / 2, 1.0)
                else:
                    concentration = 0.0
                feats["mean_diff"] = round(mean_diff, 2)
                feats["concentration"] = round(concentration, 4)
                score = (
                    (area / 500.0) * 0.3 +
                    (ratio / 10.0) * 0.35 +
                    (mean_diff / 50.0) * 0.2 +
                    concentration * 0.15
                )
            else:
                score = area * (ratio / 10.0)

            items.append({
                "score": float(score),
                "features": feats,
                "box": box,
                "center": (cx, cy),
                "angle": angle,
                "length": length,
            })
            if score > best:
                best = float(score)
        return items, best

    def _thresh(self, diff: np.ndarray, regions) -> np.ndarray:
        """差分图 -> 二值化 + 形态学开/闭 + 选区掩码"""
        h, w = diff.shape
        mask = regions_to_mask((h, w), regions)
        if self.bottom_band > 0:
            mask[-self.bottom_band:, :] = 0  # 忽略画面底部条带
        diff = diff * (mask > 0)
        diff_u8 = np.clip(diff, 0, 255).astype(np.uint8)
        _, thresh = cv2.threshold(diff_u8, int(self.diff_threshold), 255, cv2.THRESH_BINARY)
        kernel_open = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        kernel_close = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel_open)
        thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel_close)
        return thresh

    # -- 两种模式 ------------------------------------------------------------
    def analyze_pair(
        self, prev_gray: np.ndarray, curr_gray: np.ndarray, regions=None
    ) -> Tuple[bool, float, dict, list, list]:
        """帧间差分（算法二）：绝对差分 + 综合得分。
        返回 (hit, score, features, boxes, lines)，lines = 全部候选线（含中心/角度）"""
        diff = np.abs(curr_gray - prev_gray).astype(np.float32)
        thresh = self._thresh(diff, regions)
        items, best = self._contour_items(diff, thresh, self.min_area,
                                          self.min_ratio, self.max_ratio, True,
                                          drop_border=self.drop_border)
        hit_items = [it for it in items if it["score"] >= self.min_score]
        if hit_items:
            top = max(hit_items, key=lambda it: it["score"])
            return True, top["score"], top["features"], [it["box"] for it in hit_items], hit_items
        return False, 0.0, dict(_EMPTY_FEATURES), [], []

    def analyze_window(
        self, frames: Sequence[np.ndarray], center_idx: int, regions=None
    ) -> Tuple[bool, float, dict, list, list]:
        """滑动窗口（算法一）：窗口中值底图差分，只保留增亮部分。
        返回 (hit, score, features, boxes, lines)"""
        stack = np.stack(frames, axis=0)
        bg = np.median(stack, axis=0)
        curr = frames[center_idx]
        diff = np.clip(curr - bg, 0, 255).astype(np.float32)
        thresh = self._thresh(diff, regions)
        items, best = self._contour_items(diff, thresh, self.min_area,
                                          self.min_ratio, self.max_ratio, False,
                                          drop_border=self.drop_border)
        if items:
            top = max(items, key=lambda it: it["score"])
            return True, top["score"], top["features"], [it["box"] for it in items], items
        return False, 0.0, dict(_EMPTY_FEATURES), [], []

    # -- 单帧测试入口 ---------------------------------------------------------
    def analyze_frames(
        self,
        curr_gray: np.ndarray,
        prev_gray: Optional[np.ndarray] = None,
        window_frames: Optional[Sequence[np.ndarray]] = None,
        center_idx: Optional[int] = None,
        regions=None,
    ) -> dict:
        """
        对内存中的灰度帧执行检测（视频拆帧等流式场景）。
        - window_frames 足量（>= window_size）时用滑动窗口底图（中心默认 len//2，
          流式场景传 center_idx=len-1 表示"以最近窗口为底图"）
        - 否则退回帧间差分（prev_gray）；两者都没有则跳过（首帧）
        返回: {hit, score, features, boxes, width, height, mode}
        """
        if window_frames is not None and len(window_frames) >= self.window_size:
            if center_idx is None:
                center_idx = self.window_size // 2
            hit, score, feats, boxes, lines = self.analyze_window(
                list(window_frames), center_idx, regions)
            mode = "window"
        elif prev_gray is not None:
            hit, score, feats, boxes, lines = self.analyze_pair(prev_gray, curr_gray, regions)
            mode = "diff"
        else:
            hit, score, feats, boxes, lines = False, 0.0, dict(_EMPTY_FEATURES), [], []
            mode = "skip"
        h, w = curr_gray.shape[:2]
        return {
            "hit": bool(hit),
            "score": score,
            "features": feats,
            "boxes": boxes,
            "lines": lines,
            "width": int(w),
            "height": int(h),
            "mode": mode,
        }

    def analyze(
        self,
        path,
        prev_path: Optional[str] = None,
        window_paths: Optional[Sequence[str]] = None,
        regions=None,
    ) -> dict:
        """
        单帧检测。window 模式需传入完整窗口路径（中心 = len//2）；
        窗口不足/无前一帧时自动降级（首帧跳过）。
        """
        if window_paths and len(window_paths) >= self.window_size:
            frames = [self.read_gray(p) for p in window_paths[: self.window_size]]
            return self.analyze_frames(frames[self.window_size // 2], window_frames=frames, regions=regions)
        if prev_path:
            return self.analyze_frames(
                self.read_gray(path), prev_gray=self.read_gray(prev_path), regions=regions)
        return self.analyze_frames(self.read_gray(path), regions=regions)


# ---------------------------------------------------------------------------
# 批量检测驱动
# ---------------------------------------------------------------------------
def analyze_one(payload: dict) -> dict:
    """
    多进程并行工作函数：独立分析单帧。
    payload: {path, prev_path?|window_paths?, params, regions, save_marked}
    """
    p = merge_params(payload.get("params"))
    det = MeteorDetector(
        diff_threshold=p["diff_threshold"],
        min_area=p["min_area"],
        min_ratio=p["min_ratio"],
        max_ratio=p["max_ratio"],
        min_score=p["min_score"],
        window_size=p["window_size"],
        use_half_size=p["use_half_size"],
        no_auto_bright=p["no_auto_bright"],
    )
    path = Path(payload["path"])
    try:
        res = det.analyze(
            str(path),
            prev_path=payload.get("prev_path"),
            window_paths=payload.get("window_paths"),
            regions=payload.get("regions") or [],
        )
        item: dict = {
            "path": str(path),
            "name": path.name,
            "hit": bool(res["hit"]),
            "score": res["score"],
            "features": res["features"],
            "boxes": res["boxes"],
            "lines": res["lines"],  # 全部候选线（飞机过滤用）
        }
        if res["hit"] and payload.get("save_marked") and not payload.get("skip_marked"):
            try:
                marked = draw_marks(det.read_rgb(path), res["boxes"], res["score"])
                ok, buf = cv2.imencode(
                    ".jpg", cv2.cvtColor(marked, cv2.COLOR_RGB2BGR),
                    [cv2.IMWRITE_JPEG_QUALITY, 92],
                )
                if ok:
                    item["marked_bytes"] = buf.tobytes()
            except Exception:
                pass
        return item
    except Exception as e:
        return {"path": str(path), "name": path.name, "hit": False, "lines": [], "error": str(e)}


def _build_tasks(
    files: Sequence[str], p: dict, regions, skip_marked: bool = False
) -> Tuple[List[Optional[dict]], int]:
    """构建每帧任务：diff 首帧跳过；window 中间帧带窗口路径，边界帧用差分"""
    total = len(files)
    half = p["window_size"] // 2 if p["mode"] == "window" else 0
    tasks: List[Optional[dict]] = [None] * total
    n_submitted = 0
    for i, f in enumerate(files):
        if i == 0:
            continue  # 首帧作为背景
        if p["mode"] == "window" and half <= i < total - half:
            tasks[i] = {
                "path": f,
                "window_paths": list(files[i - half: i + half + 1]),
                "params": p,
                "regions": regions,
                "save_marked": True,
                "skip_marked": skip_marked,
            }
        else:
            tasks[i] = {
                "path": f,
                "prev_path": files[i - 1],
                "params": p,
                "regions": regions,
                "save_marked": True,
                "skip_marked": skip_marked,
            }
        n_submitted += 1
    return tasks, n_submitted


def _batch_detect_parallel(
    files: Sequence[str],
    output_dir: str,
    params: Optional[dict],
    regions: Optional[Sequence[dict]],
    prefix: str,
    save_marked: bool,
    output_format: str,
    progress_cb: Optional[Callable[[int, int, int, str], None]],
    cancel_event=None,
) -> dict:
    """多进程并行批量检测（结果按文件顺序输出，与串行一致；含飞机过滤）"""
    p = merge_params(params)
    total = len(files)
    filter_on = bool(p.get("aircraft_filter"))
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    mark_dir = out_dir / "marked" if save_marked else None

    tasks, n_submitted = _build_tasks(files, p, regions, skip_marked=filter_on)
    n_workers = max(1, min(os.cpu_count() or 1, 4))
    results: List[Optional[dict]] = [None] * total
    processed = 0
    hits = 0
    cancelled = False

    with ProcessPoolExecutor(max_workers=n_workers) as pool:
        futs: Dict[Future, int] = {}
        for i, t in enumerate(tasks):
            if cancel_event is not None and cancel_event.is_set():
                cancelled = True
                break
            if t is None:
                continue
            futs[pool.submit(analyze_one, t)] = i

        for fut in as_completed(futs):
            i = futs[fut]
            if cancel_event is not None and cancel_event.is_set() and not cancelled:
                cancelled = True
                for f2 in futs:
                    f2.cancel()
            try:
                item = fut.result()
            except CancelledError:
                continue
            except Exception as e:
                item = {
                    "path": str(tasks[i]["path"]),
                    "name": Path(tasks[i]["path"]).name,
                    "hit": False,
                    "lines": [],
                    "error": str(e),
                }
            results[i] = item
            if item.get("hit"):
                hits += 1
            if not item.get("error"):
                processed += 1
            if progress_cb:
                done = sum(1 for r in results if r is not None)
                progress_cb(done, total, hits, item.get("name") or "")

    if progress_cb:
        progress_cb(sum(1 for r in results if r is not None), total, hits, "")

    # 飞机过滤：跨帧轨迹关联（父进程统一执行，保证与串行一致）
    if filter_on:
        frame_lines: List[List[dict]] = [
            (item.get("lines") or []) if item is not None else []
            for item in results
        ]
        keep = apply_aircraft_filter(frame_lines, p)
        for i, item in enumerate(results):
            if item is None:
                continue
            rebuilt = rebuild_from_kept(frame_lines[i], keep, i)
            if rebuilt is None:
                item["hit"] = False
                item["score"] = 0.0
                item["features"] = dict(_EMPTY_FEATURES)
                item["boxes"] = []
            else:
                item["hit"] = True
                item["score"] = rebuilt["score"]
                item["features"] = rebuilt["features"]
                item["boxes"] = rebuilt["boxes"]
        hits = sum(1 for r in results if r is not None and r.get("hit"))

    # 按文件顺序写输出（命中编号与串行一致）
    copied = 0
    hit_no = 0
    out_results: List[dict] = []
    det = None
    for i, item in enumerate(results):
        if item is None:
            # 未提交的帧（首帧背景帧，或取消后未处理帧）：输出为非命中占位，与串行对齐
            out_results.append({
                "path": str(files[i]),
                "name": Path(files[i]).name,
                "hit": False,
                "score": 0.0,
                "features": dict(_EMPTY_FEATURES),
                "boxes": [],
            })
            continue
        out_results.append(item)
        if not item.get("hit"):
            continue
        hit_no += 1
        path = Path(item["path"])
        dst = copy_result(path, out_dir, prefix, hit_no, item["score"], output_format)
        marked = None
        if save_marked and dst is not None:
            try:
                if item.get("marked_bytes"):
                    mark_path = (mark_dir or out_dir) / f"{dst.stem}_marked.jpg"
                    mark_path.parent.mkdir(parents=True, exist_ok=True)
                    mark_path.write_bytes(item["marked_bytes"])
                    marked = str(mark_path)
                elif filter_on:
                    # 过滤可能改变了命中线：父进程按过滤后的框重画标记图
                    if det is None:
                        det = MeteorDetector(
                            diff_threshold=p["diff_threshold"],
                            min_area=p["min_area"],
                            min_ratio=p["min_ratio"],
                            max_ratio=p["max_ratio"],
                            min_score=p["min_score"],
                            window_size=p["window_size"],
                            use_half_size=p["use_half_size"],
                            no_auto_bright=p["no_auto_bright"],
                        )
                    marked = write_marked_image(
                        det.read_rgb(str(path)), item["boxes"], item["score"], mark_dir or out_dir, dst.stem,
                    )
            except Exception:
                marked = None
        if dst is not None:
            copied += 1
        item["dst"] = str(dst) if dst else None
        item["marked"] = marked
        item.pop("marked_bytes", None)

    return {
        "total": total,
        "processed": processed,
        "hits": hits,
        "copied": copied,
        "cancelled": cancelled,
        "results": out_results,
    }


def batch_detect(
    files: Sequence[str],
    output_dir: str,
    params: Optional[dict] = None,
    regions: Optional[Sequence[dict]] = None,
    prefix: str = "meteor",
    save_marked: bool = False,
    output_format: str = "orig",
    progress_cb: Optional[Callable[[int, int, int, str], None]] = None,
    cancel_event=None,
    parallel: bool = False,
) -> dict:
    """
    批量检测：
      mode=diff   -> 相邻帧差分（首帧作为背景跳过）
      mode=window -> 滑动窗口中值底图差分（边界帧自动回退差分）
    返回: {total, processed, hits, copied, results:[{path, hit, score, features, boxes, dst, marked}]}
    """
    total = len(files)
    if parallel and total >= 4:
        return _batch_detect_parallel(
            files, output_dir, params, regions, prefix,
            save_marked, output_format, progress_cb, cancel_event,
        )

    p = merge_params(params)
    filter_on = bool(p.get("aircraft_filter"))
    det = MeteorDetector(
        diff_threshold=p["diff_threshold"],
        min_area=p["min_area"],
        min_ratio=p["min_ratio"],
        max_ratio=p["max_ratio"],
        min_score=p["min_score"],
        window_size=p["window_size"],
        use_half_size=p["use_half_size"],
        no_auto_bright=p["no_auto_bright"],
    )

    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    mark_dir = out_dir / "marked" if save_marked else None
    if mark_dir is not None:
        mark_dir.mkdir(parents=True, exist_ok=True)

    processed = 0
    hits = 0
    results: List[dict] = []
    frame_lines: List[List[dict]] = []  # 每帧候选线（飞机过滤用，与 files 对齐）
    half = p["window_size"] // 2 if p["mode"] == "window" else 0
    window: deque = deque(maxlen=p["window_size"])  # 滑动窗口：(index, gray)
    read_upto = -1
    last_gray = None  # 帧间差分模式：上一帧灰度

    for i, fpath in enumerate(files):
        if cancel_event is not None and cancel_event.is_set():
            break
        path = Path(fpath)

        # 首帧作为背景（两种模式都无前一帧）
        if i == 0:
            if p["mode"] == "window":
                window.append((0, det.read_gray(fpath)))
                read_upto = 0
            frame_lines.append([])
            results.append({
                "path": str(path),
                "name": path.name,
                "hit": False,
                "score": 0.0,
                "features": dict(_EMPTY_FEATURES),
                "boxes": [],
            })
            if progress_cb:
                progress_cb(i + 1, total, hits, path.name)
            continue

        if p["mode"] == "window":
            # 前瞻读入到 i+half，窗口只保留 [i-half, i+half]
            target = min(i + half, total - 1)
            while window and window[0][0] < i - half:
                window.popleft()
            while read_upto < target:
                read_upto += 1
                window.append((read_upto, det.read_gray(files[read_upto])))
            center = next((g for idx, g in window if idx == i), None)
            if center is None:
                center = det.read_gray(fpath)
                window.append((i, center))
                read_upto = max(read_upto, i)
            if i - half < 0 or i + half >= total:
                prev = next((g for idx, g in window if idx == i - 1), None)
                if prev is not None:
                    hit, score, feats, boxes, lines = det.analyze_pair(prev, center, regions)
                else:
                    hit, score, feats, boxes, lines = False, 0.0, dict(_EMPTY_FEATURES), [], []
            else:
                frames = [g for _, g in window]
                hit, score, feats, boxes, lines = det.analyze_window(frames, half, regions)
            last_gray = center
        else:
            gray = det.read_gray(fpath)
            if last_gray is not None:
                hit, score, feats, boxes, lines = det.analyze_pair(last_gray, gray, regions)
            else:
                hit, score, feats, boxes, lines = False, 0.0, dict(_EMPTY_FEATURES), [], []
            last_gray = gray

        processed += 1
        if hit:
            hits += 1
        frame_lines.append(lines if hit else [])
        results.append({
            "path": str(path),
            "name": path.name,
            "hit": hit,
            "score": score,
            "features": feats,
            "boxes": boxes,
        })
        if progress_cb:
            progress_cb(i + 1, total, hits, path.name)

    # 飞机过滤：跨帧轨迹关联（收集完所有帧后统一执行）
    if filter_on:
        keep = apply_aircraft_filter(frame_lines, p)
        for i, item in enumerate(results):
            rebuilt = rebuild_from_kept(frame_lines[i], keep, i)
            if rebuilt is None:
                item["hit"] = False
                item["score"] = 0.0
                item["features"] = dict(_EMPTY_FEATURES)
                item["boxes"] = []
            else:
                item["hit"] = True
                item["score"] = rebuilt["score"]
                item["features"] = rebuilt["features"]
                item["boxes"] = rebuilt["boxes"]
        hits = sum(1 for it in results if it["hit"])

    # 写输出（文件顺序；命中编号从 1 开始）
    copied = 0
    hit_no = 0
    for item in results:
        if not item["hit"]:
            continue
        hit_no += 1
        path = Path(item["path"])
        dst = copy_result(path, out_dir, prefix, hit_no, item["score"], output_format)
        marked = None
        if save_marked and dst is not None:
            marked = write_marked_image(
                det.read_rgb(path), item["boxes"], item["score"], mark_dir or out_dir, f"{dst.stem}",
            )
        if dst is not None:
            copied += 1
        item["dst"] = str(dst) if dst else None
        item["marked"] = str(marked) if marked else None

    return {
        "total": total,
        "processed": processed,
        "hits": hits,
        "copied": copied,
        "cancelled": cancel_event is not None and cancel_event.is_set(),
        "results": results,
    }
