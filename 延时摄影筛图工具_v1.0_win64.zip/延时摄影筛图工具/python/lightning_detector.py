#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
闪电检测核心算法 —— 由《一个简单的闪电检测脚本》重构为可复用库

保留原有算法（帧间差分 + 颜色特征 + 空间集中度打分），新增：
  * 多格式读取（RAW: NEF/CR2/CR3/ARW/DNG/ORF/RW2...；通用: JPG/PNG/TIFF/BMP/WebP）
  * 单帧阈值模式（适合单张长曝光）
  * 归一化选区过滤（rect / polygon，0-1 坐标）
  * 命中区域连通域框（box）输出 + 标记图生成
  * 批量检测驱动（进度回调 + 取消事件）

依赖: pip install numpy opencv-python-headless rawpy tqdm
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from concurrent.futures import CancelledError, Future, ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

import cv2
import numpy as np

try:
    import rawpy
except Exception:  # pragma: no cover - 环境检查阶段友好降级
    rawpy = None

try:
    from PIL import Image
    HAS_PIL = True
except Exception:
    HAS_PIL = False

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------
RAW_EXTS = {
    ".cr2", ".cr3", ".nef", ".nrw", ".arw", ".srf", ".sr2", ".raf",
    ".dng", ".orf", ".pef", ".rw2", ".raw", ".rwl", ".srw", ".x3f",
    ".kdc", ".dcr", ".mef", ".erf", ".iiq", ".3fr", ".mrw",
}
IMAGE_EXTS = RAW_EXTS | {
    ".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp", ".webp", ".gif",
}

DEFAULT_PARAMS = {
    "mode": "diff",            # diff=连续帧差分 | single=单帧阈值
    "sensitivity": 50,         # 1-100 前端灵敏度滑块
    "min_score": 0.5,          # 综合得分阈值（sensitivity 映射后的结果）
    "diff_threshold": 35.0,    # 帧间单像素亮度差阈值
    "min_bright_pixels": 300,  # 最小突变像素数
    "min_brightness": 180.0,   # 单帧模式最小亮度阈值（0-255）
    "min_area": 200,           # 单帧模式最小连通区域面积（像素）
    "sky_ratio": 0.55,         # 天空区域占画面高度比例
    "color_weight": 0.3,       # 颜色特征权重
    "use_half_size": True,     # 半分辨率加速
    "no_auto_bright": True,    # 关闭 RAW 自动亮度
}


def sensitivity_to_min_score(sensitivity: float) -> float:
    """灵敏度 1-100 -> 得分阈值（越高越激进，阈值越低）"""
    sens = max(1.0, min(100.0, float(sensitivity)))
    return round(0.90 - 0.45 * (sens / 100.0), 3)


def merge_params(raw: Optional[dict]) -> dict:
    """合并默认参数与用户参数（含灵敏度映射）"""
    params = dict(DEFAULT_PARAMS)
    if raw:
        for k, v in raw.items():
            if k in params and v is not None:
                params[k] = v
    if "sensitivity" in params:
        params["min_score"] = float(params.get("min_score") or sensitivity_to_min_score(params["sensitivity"]))
    return params


# ---------------------------------------------------------------------------
# 图像读取
# ---------------------------------------------------------------------------
def read_image(path, use_half_size: bool = True, no_auto_bright: bool = True) -> np.ndarray:
    """读取任意支持格式为 RGB numpy 数组（uint8，0-255）"""
    path = Path(path)
    ext = path.suffix.lower()

    if ext in RAW_EXTS:
        if rawpy is None:
            raise RuntimeError("未安装 rawpy，无法解码 RAW 文件")
        with rawpy.imread(str(path)) as raw:
            rgb = raw.postprocess(
                use_camera_wb=True,
                no_auto_bright=no_auto_bright,
                half_size=use_half_size,
            )
        return np.asarray(rgb)

    img = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if img is None and HAS_PIL:
        with Image.open(path) as im:
            img = np.asarray(im.convert("RGB"))
        return img
    if img is None:
        raise ValueError(f"无法解码图像: {path}")
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    if use_half_size and max(img.shape[:2]) > 1024:
        h, w = img.shape[:2]
        img = cv2.resize(img, (w // 2, h // 2), interpolation=cv2.INTER_AREA)
    return img


def regions_to_mask(shape_hw: Tuple[int, int], regions: Optional[Sequence[dict]]) -> np.ndarray:
    """
    归一化选区 -> uint8 掩码（255=检测区）。
    regions: [{type:'rect', points:[[x0,y0],[x1,y1]]} | {type:'polygon', points:[[x,y],...]}]
    坐标为 0-1 归一化。regions 为空 -> 全图掩码。
    """
    h, w = shape_hw
    if not regions:
        return np.full((h, w), 255, np.uint8)
    mask = np.zeros((h, w), np.uint8)
    for r in regions:
        rtype = r.get("type", "rect")
        pts = r.get("points") or []
        if rtype == "rect" and len(pts) >= 2:
            x0 = max(0, min(w, int(pts[0][0] * w)))
            y0 = max(0, min(h, int(pts[0][1] * h)))
            x1 = max(0, min(w, int(pts[1][0] * w)))
            y1 = max(0, min(h, int(pts[1][1] * h)))
            x0, x1 = sorted((x0, x1))
            y0, y1 = sorted((y0, y1))
            if x1 > x0 and y1 > y0:
                mask[y0:y1, x0:x1] = 255
        elif rtype == "polygon" and len(pts) >= 3:
            poly = np.array([[int(p[0] * w), int(p[1] * h)] for p in pts], np.int32)
            cv2.fillPoly(mask, [poly], 255)
    if not np.any(mask):
        # 选区全部无效时退回全图，避免误伤
        return np.full((h, w), 255, np.uint8)
    return mask


def _boxes_from_mask(mask: np.ndarray, min_area: int = 30) -> List[Tuple[int, int, int, int]]:
    """连通域 -> 归一化 bbox 列表 [[x0,y0,x1,y1]]"""
    h, w = mask.shape
    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), connectivity=8)
    boxes = []
    for i in range(1, n):
        x, y, bw, bh, area = stats[i]
        if area < min_area:
            continue
        boxes.append((
            round(x / w, 4), round(y / h, 4),
            round((x + bw) / w, 4), round((y + bh) / h, 4),
        ))
    return boxes


# ---------------------------------------------------------------------------
# 检测器
# ---------------------------------------------------------------------------
class LightningDetector:
    """白天场景闪电检测器 —— 基于局部亮度突变和颜色特征（保留原算法）"""

    def __init__(
        self,
        diff_threshold: float = 35.0,
        min_bright_pixels: int = 300,
        sky_ratio: float = 0.55,
        color_weight: float = 0.3,
        min_score: float = 0.5,
        min_brightness: float = 180.0,
        min_area: int = 200,
        use_half_size: bool = True,
        no_auto_bright: bool = True,
    ):
        self.diff_threshold = diff_threshold
        self.min_bright_pixels = min_bright_pixels
        self.sky_ratio = sky_ratio
        self.color_weight = color_weight
        self.min_score = min_score
        self.min_brightness = min_brightness
        self.min_area = min_area
        self.use_half_size = use_half_size
        self.no_auto_bright = no_auto_bright

    # -- 读取 --------------------------------------------------------------
    def read(self, filepath: Path) -> np.ndarray:
        return read_image(filepath, self.use_half_size, self.no_auto_bright)

    # -- 特征 --------------------------------------------------------------
    def _compute_diff_features(
        self, img_prev: np.ndarray, img_curr: np.ndarray, region_mask: Optional[np.ndarray] = None
    ) -> dict:
        """两帧差分特征（天空区域 + 选区过滤）"""
        h = img_curr.shape[0]
        sky_h = int(h * self.sky_ratio)
        sky_prev = img_prev[:sky_h, :]
        sky_curr = img_curr[:sky_h, :]

        prev_f = sky_prev.astype(np.float32)
        curr_f = sky_curr.astype(np.float32)

        gray_prev = np.mean(prev_f, axis=2)
        gray_curr = np.mean(curr_f, axis=2)
        gray_diff = gray_curr - gray_prev

        bright_mask = gray_diff > self.diff_threshold

        # 选区过滤（裁切到天空区域）
        if region_mask is not None:
            bright_mask = bright_mask & (region_mask[:sky_h, :] > 0)

        bright_pixels = int(np.sum(bright_mask))
        avg_bright = float(np.mean(gray_diff[bright_mask])) if bright_pixels > 0 else 0.0

        blue_ratio = 0.0
        high_luma = 0.0
        if bright_pixels > 0:
            bright_curr = curr_f[bright_mask]
            r, g, b = bright_curr[:, 0], bright_curr[:, 1], bright_curr[:, 2]
            blue_ratio = float(np.mean(b / (r + g + b + 1e-6)))
            high_luma = float(np.mean((r + g + b) / 3 > 150))
        else:
            blue_ratio = 0.0
            high_luma = 0.0

        concentration = 0.0
        if bright_pixels > 0:
            y_coords, x_coords = np.where(bright_mask)
            y_std = float(np.std(y_coords)) if len(y_coords) > 1 else 0.0
            x_std = float(np.std(x_coords)) if len(x_coords) > 1 else 0.0
            concentration = 1.0 - min((y_std / sky_h + x_std / sky_curr.shape[1]) / 2, 1.0)

        return {
            "bright_pixels": bright_pixels,
            "avg_bright": avg_bright,
            "blue_ratio": blue_ratio,
            "high_luma": high_luma,
            "concentration": concentration,
        }

    def _compute_single_features(
        self, img: np.ndarray, region_mask: Optional[np.ndarray] = None
    ) -> dict:
        """单帧阈值特征（整帧亮度 + 白蓝色 + 连通域）"""
        f = img.astype(np.float32)
        gray = np.mean(f, axis=2)

        bright_mask = gray > self.min_brightness
        if region_mask is not None:
            bright_mask = bright_mask & (region_mask > 0)

        # 形态学去噪
        kernel = np.ones((3, 3), np.uint8)
        bright_mask = cv2.morphologyEx(
            bright_mask.astype(np.uint8), cv2.MORPH_OPEN, kernel
        ) > 0

        bright_pixels = int(np.sum(bright_mask))
        avg_bright = float(np.mean(gray[bright_mask])) if bright_pixels > 0 else 0.0

        blue_ratio = 0.0
        high_luma = 0.0
        if bright_pixels > 0:
            bright_curr = f[bright_mask]
            r, g, b = bright_curr[:, 0], bright_curr[:, 1], bright_curr[:, 2]
            blue_ratio = float(np.mean(b / (r + g + b + 1e-6)))
            high_luma = float(np.mean(gray[bright_mask] > 200))
        else:
            high_luma = 0.0

        # 连通域统计：集中度 + 面积
        n, labels, stats, _ = cv2.connectedComponentsWithStats(
            bright_mask.astype(np.uint8), connectivity=8
        )
        areas = [stats[i, cv2.CC_STAT_AREA] for i in range(1, n)]
        total_area = int(np.sum(areas)) if areas else 0
        if total_area > 0:
            y_coords, x_coords = np.where(bright_mask)
            hh, ww = bright_mask.shape
            concentration = 1.0 - min(
                (np.std(y_coords) / hh + np.std(x_coords) / ww) / 2, 1.0
            )
        else:
            concentration = 0.0

        return {
            "bright_pixels": total_area,
            "avg_bright": avg_bright,
            "blue_ratio": blue_ratio,
            "high_luma": high_luma,
            "concentration": concentration,
        }

    @staticmethod
    def _score_frame(features: dict, color_weight: float) -> float:
        """综合打分 0-1（保留原权重）"""
        pixel_score = min(features["bright_pixels"] / 2000.0, 1.0)
        bright_score = min(features["avg_bright"] / 100.0, 1.0)
        color_score = min(features["blue_ratio"] * features["high_luma"] * 3.0, 1.0)
        conc_score = features["concentration"]
        return float(
            pixel_score * 0.35
            + bright_score * 0.25
            + color_score * color_weight
            + conc_score * 0.15
        )

    # -- 对外接口 -----------------------------------------------------------
    def analyze(
        self,
        curr_path,
        prev_path: Optional = None,
        regions: Optional[Sequence[dict]] = None,
    ) -> dict:
        """
        对单张图片执行检测。
        - mode=diff: 需要 prev_path（与前一帧差分）
        - mode=single: 单帧阈值
        返回: {hit, score, features, boxes, width, height}
        """
        img_curr = self.read(curr_path)
        img_prev = self.read(prev_path) if prev_path is not None else None
        return self.analyze_rgb(img_curr, img_prev, regions)

    def analyze_rgb(
        self,
        img_curr: np.ndarray,
        img_prev: Optional[np.ndarray] = None,
        regions: Optional[Sequence[dict]] = None,
    ) -> dict:
        """
        对内存中的 RGB 帧执行检测（视频拆帧等流式场景）。
        img_curr / img_prev 为 RGB uint8 数组。
        返回同 analyze()。
        """
        h, w = img_curr.shape[:2]
        region_mask = regions_to_mask((h, w), regions)

        if img_prev is not None:
            features = self._compute_diff_features(img_prev, img_curr, region_mask)
        else:
            features = self._compute_single_features(img_curr, region_mask)

        score = self._score_frame(features, self.color_weight)
        hit = score >= self.min_score and features["bright_pixels"] >= self.min_bright_pixels

        boxes = []
        if hit:
            # 重新构建亮区掩码用于连通域（差分模式下与特征一致）
            if img_prev is not None:
                sky_h = int(h * self.sky_ratio)
                prev_f = img_prev[:sky_h, :].astype(np.float32)
                curr_f = img_curr[:sky_h, :].astype(np.float32)
                diff = np.mean(curr_f, axis=2) - np.mean(prev_f, axis=2)
                m = (diff > self.diff_threshold) & (region_mask[:sky_h, :] > 0)
            else:
                gray = np.mean(img_curr.astype(np.float32), axis=2)
                m = (gray > self.min_brightness) & (region_mask > 0)
            boxes = _boxes_from_mask(m.astype(np.uint8), min_area=self.min_area)

        return {
            "hit": hit,
            "score": round(score, 4),
            "features": {
                "bright_pixels": features["bright_pixels"],
                "avg_bright": round(features["avg_bright"], 2),
                "blue_ratio": round(features["blue_ratio"], 4),
                "concentration": round(features["concentration"], 4),
            },
            "boxes": boxes,
            "width": int(w),
            "height": int(h),
        }


# ---------------------------------------------------------------------------
# 标记图 / 输出
# ---------------------------------------------------------------------------
def draw_marks(img_rgb: np.ndarray, boxes, score: float) -> np.ndarray:
    """在图像上叠加检测框与得分（绿色框 + 标签）"""
    out = img_rgb.copy()
    h, w = out.shape[:2]
    for (x0, y0, x1, y1) in boxes:
        p0 = (int(x0 * w), int(y0 * h))
        p1 = (int(x1 * w), int(y1 * h))
        cv2.rectangle(out, p0, p1, (0, 255, 0), max(2, w // 400))
    label = f"score {score:.3f}"
    cv2.putText(out, label, (12, 28), cv2.FONT_HERSHEY_SIMPLEX,
                0.7, (0, 255, 0), 2, cv2.LINE_AA)
    return out


def write_marked_image(src_rgb: np.ndarray, boxes, score: float, dst_dir: Path, stem: str) -> Optional[Path]:
    """保存标记图（JPG）"""
    try:
        marked = draw_marks(src_rgb, boxes, score)
        bgr = cv2.cvtColor(marked, cv2.COLOR_RGB2BGR)
        dst = dst_dir / f"{stem}_marked.jpg"
        cv2.imencode(".jpg", bgr, [cv2.IMWRITE_JPEG_QUALITY, 92])[1].tofile(str(dst))
        return dst
    except Exception:
        return None


def copy_result(
    src_path: Path,
    dst_dir: Path,
    prefix: str,
    idx: int,
    score: float,
    output_format: str = "orig",
) -> Optional[Path]:
    """复制/转码命中文件到输出目录，返回目标路径"""
    dst_dir.mkdir(parents=True, exist_ok=True)
    score_str = f"{score:.3f}"
    stem = f"{prefix}_{idx:03d}_score{score_str}_{src_path.stem}"

    if output_format == "jpg":
        img = read_image(src_path, use_half_size=False)
        dst = dst_dir / f"{stem}.jpg"
        ok, buf = cv2.imencode(".jpg", cv2.cvtColor(img, cv2.COLOR_RGB2BGR),
                               [cv2.IMWRITE_JPEG_QUALITY, 95])
        if not ok:
            return None
        buf.tofile(str(dst))
        return dst
    if output_format == "png":
        img = read_image(src_path, use_half_size=False)
        dst = dst_dir / f"{stem}.png"
        ok, buf = cv2.imencode(".png", cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
        if not ok:
            return None
        buf.tofile(str(dst))
        return dst

    # 原格式复制
    dst = dst_dir / f"{stem}{src_path.suffix.lower()}"
    try:
        shutil.copy2(src_path, dst)
        return dst
    except Exception:
        return None


# ---------------------------------------------------------------------------
# 批量检测驱动
# ---------------------------------------------------------------------------
def analyze_one(payload: dict) -> dict:
    """
    多进程并行的工作函数：独立分析单帧。
    payload 必须全部为可 pickle 的基础类型（路径/参数/选区都是 JSON 友好结构）。
    返回: {path, name, hit, score, boxes, marked_bytes?} 或 {path, name, hit:False, error}
    """
    p = merge_params(payload.get("params"))
    detector = LightningDetector(
        diff_threshold=p["diff_threshold"],
        min_bright_pixels=p["min_bright_pixels"],
        sky_ratio=p["sky_ratio"],
        color_weight=p["color_weight"],
        min_score=p["min_score"],
        min_brightness=p["min_brightness"],
        min_area=p["min_area"],
        use_half_size=p["use_half_size"],
        no_auto_bright=p["no_auto_bright"],
    )
    path = Path(payload["path"])
    try:
        res = detector.analyze(
            str(path),
            prev_path=payload.get("prev_path"),
            regions=payload.get("regions") or [],
        )
        item: dict = {
            "path": str(path),
            "name": path.name,
            "hit": bool(res["hit"]),
            "score": res["score"],
            "boxes": res["boxes"],
        }
        if res["hit"] and payload.get("save_marked"):
            try:
                marked = draw_marks(detector.read(path), res["boxes"], res["score"])
                ok, buf = cv2.imencode(
                    ".jpg", cv2.cvtColor(marked, cv2.COLOR_RGB2BGR),
                    [cv2.IMWRITE_JPEG_QUALITY, 92],
                )
                if ok:
                    item["marked_bytes"] = buf.tobytes()
            except Exception:
                pass
        return item
    except Exception as e:
        return {"path": str(path), "name": path.name, "hit": False, "error": str(e)}


def _batch_detect_parallel(
    files: Sequence[str],
    output_dir: str,
    params: Optional[dict],
    regions: Optional[Sequence[dict]],
    prefix: str,
    save_marked: bool,
    output_format: str,
    progress_cb: Optional[Callable[[int, int, int, str], None]],
    cancel_event=None,
) -> dict:
    """
    多进程并行批量检测：
      * 每帧在独立子进程中分析（CPU 多核并行，绕开 GIL）
      * 文件写入在父进程按文件顺序统一进行 -> 命中编号/文件名与串行模式完全一致
      * 取消 = 停止提交新任务（已在运行的帧会自然完成）
      * 各进程互不共享内存，worker 数取 min(CPU 核数, 4) 以控制内存占用
    """
    p = merge_params(params)
    total = len(files)
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    mark_dir = out_dir / "marked" if save_marked else None

    # 任务构建（diff 模式首帧跳过，仅作为背景）
    tasks: List[Optional[dict]] = []
    for i, f in enumerate(files):
        if p["mode"] == "diff" and i == 0:
            tasks.append(None)
            continue
        tasks.append({
            "path": f,
            "prev_path": files[i - 1] if p["mode"] == "diff" else None,
            "params": p,
            "regions": regions,
            "save_marked": bool(save_marked),
        })

    n_workers = max(1, min(os.cpu_count() or 1, 4))
    results: List[Optional[dict]] = [None] * total
    processed = 0
    hits = 0
    cancelled = False

    with ProcessPoolExecutor(max_workers=n_workers) as pool:
        futs: Dict[Future, int] = {}
        for i, t in enumerate(tasks):
            if cancel_event is not None and cancel_event.is_set():
                cancelled = True
                break
            if t is None:
                continue
            futs[pool.submit(analyze_one, t)] = i

        for fut in as_completed(futs):
            i = futs[fut]
            # 处理期间收到取消：取消尚未开始的排队任务（运行中的会自然结束）
            if cancel_event is not None and cancel_event.is_set() and not cancelled:
                cancelled = True
                for f2 in futs:
                    f2.cancel()
            try:
                item = fut.result()
            except CancelledError:
                continue  # 排队中被取消的帧：未处理
            except Exception as e:
                item = {
                    "path": str(tasks[i]["path"]),
                    "name": Path(tasks[i]["path"]).name,
                    "hit": False,
                    "error": str(e),
                }
            results[i] = item
            if item.get("hit"):
                hits += 1
            if not item.get("error"):
                processed += 1
            if progress_cb:
                done = sum(1 for r in results if r is not None)
                progress_cb(done, total, hits, item.get("name") or "")

    if progress_cb:
        progress_cb(sum(1 for r in results if r is not None), total, hits, "")

    # 按文件顺序写输出（命中编号与串行模式一致）
    copied = 0
    hit_no = 0
    out_results: List[dict] = []
    for item in results:
        if item is None:
            continue
        out_results.append(item)
        if not item.get("hit"):
            continue
        hit_no += 1
        path = Path(item["path"])
        dst = copy_result(path, out_dir, prefix, hit_no, item["score"], output_format)
        marked = None
        if save_marked and dst is not None and item.get("marked_bytes"):
            mark_path = (mark_dir or out_dir) / f"{dst.stem}_marked.jpg"
            try:
                mark_path.parent.mkdir(parents=True, exist_ok=True)
                mark_path.write_bytes(item["marked_bytes"])
                marked = str(mark_path)
            except Exception:
                marked = None
        if dst is not None:
            copied += 1
        item["dst"] = str(dst) if dst else None
        item["marked"] = marked
        item.pop("marked_bytes", None)

    return {
        "total": total,
        "processed": processed,
        "hits": hits,
        "copied": copied,
        "cancelled": cancelled,
        "results": out_results,
    }


def batch_detect(
    files: Sequence[str],
    output_dir: str,
    params: Optional[dict] = None,
    regions: Optional[Sequence[dict]] = None,
    prefix: str = "lightning",
    save_marked: bool = False,
    output_format: str = "orig",
    progress_cb: Optional[Callable[[int, int, int, str], None]] = None,
    cancel_event=None,
    parallel: bool = False,
) -> dict:
    """
    批量检测：
      mode=diff  -> 相邻帧差分（files 需按时间排序；首帧跳过，缺前一帧时用上一张成功读取的图）
      mode=single-> 逐帧单帧阈值
      parallel   -> 多核并行（按帧多进程；仅当文件数足够多时启用，小批量回退串行）
    返回: {total, processed, hits, copied, results:[{path, hit, score, dst, marked}]}
    """
    total = len(files)
    if parallel and total >= 4:
        return _batch_detect_parallel(
            files, output_dir, params, regions, prefix,
            save_marked, output_format, progress_cb, cancel_event,
        )

    p = merge_params(params)
    detector = LightningDetector(
        diff_threshold=p["diff_threshold"],
        min_bright_pixels=p["min_bright_pixels"],
        sky_ratio=p["sky_ratio"],
        color_weight=p["color_weight"],
        min_score=p["min_score"],
        min_brightness=p["min_brightness"],
        min_area=p["min_area"],
        use_half_size=p["use_half_size"],
        no_auto_bright=p["no_auto_bright"],
    )

    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    total = len(files)
    processed = 0
    hits = 0
    copied = 0
    results: List[dict] = []
    last_ok: Optional[str] = None
    mark_dir = out_dir / "marked" if save_marked else None
    if mark_dir is not None:
        mark_dir.mkdir(parents=True, exist_ok=True)

    for i, fpath in enumerate(files):
        if cancel_event is not None and cancel_event.is_set():
            break
        path = Path(fpath)
        try:
            prev = last_ok if p["mode"] == "diff" else None
            # diff 模式下首帧无前一帧 -> 跳过（保留原脚本行为）
            if p["mode"] == "diff" and prev is None:
                last_ok = str(path)  # 首帧本身作为背景
                if progress_cb:
                    progress_cb(i + 1, total, hits, path.name)
                continue
            res = detector.analyze(str(path), prev_path=prev, regions=regions)
            processed += 1
            if res["hit"]:
                hits += 1
                dst = copy_result(path, out_dir, prefix, hits, res["score"], output_format)
                marked = None
                if save_marked and dst is not None:
                    marked = write_marked_image(
                        detector.read(path), res["boxes"], res["score"],
                        mark_dir or out_dir, f"{dst.stem}",
                    )
                if dst is not None:
                    copied += 1
                results.append({
                    "path": str(path),
                    "name": path.name,
                    "hit": True,
                    "score": res["score"],
                    "boxes": res["boxes"],
                    "dst": str(dst) if dst else None,
                    "marked": str(marked) if marked else None,
                })
            else:
                results.append({
                    "path": str(path),
                    "name": path.name,
                    "hit": False,
                    "score": res["score"],
                })
            # diff 模式下，无论是否命中都更新背景
            if p["mode"] == "diff":
                last_ok = str(path)
        except Exception as e:  # 单张失败不中断批量
            results.append({
                "path": str(path),
                "name": path.name,
                "hit": False,
                "error": str(e),
            })
        if progress_cb:
            progress_cb(i + 1, total, hits, path.name)

    return {
        "total": total,
        "processed": processed,
        "hits": hits,
        "copied": copied,
        "cancelled": bool(cancel_event is not None and cancel_event.is_set()),
        "results": results,
    }


# ---------------------------------------------------------------------------
# 命令行入口（兼容原脚本用法）
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="白天延时摄影闪电自动检测工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python lightning_detector.py -i ./photos -o ./results
  python lightning_detector.py -i ./photos -o ./results --threshold 30 --min-pixels 500
  python lightning_detector.py -i ./photos -o ./results --score 0.6 --sky-ratio 0.6
  python lightning_detector.py -i ./photos -o ./results --mode single --min-brightness 200
        """,
    )
    parser.add_argument("-i", "--input", required=True, help="照片文件夹路径")
    parser.add_argument("-o", "--output", required=True, help="结果输出文件夹路径")
    parser.add_argument("--mode", choices=["diff", "single"], default="diff",
                        help="检测模式 (默认: diff)")
    parser.add_argument("--threshold", type=float, default=35.0, help="帧间亮度差阈值")
    parser.add_argument("--min-pixels", type=int, default=300, help="最小突变像素数")
    parser.add_argument("--min-brightness", type=float, default=180.0, help="单帧最小亮度")
    parser.add_argument("--min-area", type=int, default=200, help="单帧最小连通区域")
    parser.add_argument("--score", type=float, default=0.5, help="综合得分阈值 0-1")
    parser.add_argument("--sky-ratio", type=float, default=0.55, help="天空区域占画面高度比例")
    parser.add_argument("--color-weight", type=float, default=0.3, help="颜色特征权重")
    parser.add_argument("--full-res", action="store_true", help="使用全分辨率（更慢但更精确）")
    parser.add_argument("--prefix", type=str, default="lightning", help="输出文件前缀")
    parser.add_argument("--save-marked", action="store_true", help="同时保存标记图")
    parser.add_argument("--format", choices=["orig", "jpg", "png"], default="orig",
                        help="输出格式 (默认: orig)")

    args = parser.parse_args()

    input_dir = Path(args.input).expanduser().resolve()
    if not input_dir.exists():
        print(f"[X] 输入文件夹不存在: {input_dir}")
        sys.exit(1)

    files = sorted(
        p for p in input_dir.iterdir()
        if p.suffix.lower() in IMAGE_EXTS
    )
    if len(files) < (2 if args.mode == "diff" else 1):
        print(f"[!] 文件夹中图片不足: {input_dir}")
        sys.exit(0)

    print(f"[*] 共找到 {len(files)} 张图片，模式: {args.mode}")

    def cb(cur, total, hits, name):
        print(f"[*] {cur}/{total} 命中 {hits}  当前: {name}", flush=True)

    result = batch_detect(
        [str(f) for f in files],
        args.output,
        params={
            "mode": args.mode,
            "diff_threshold": args.threshold,
            "min_bright_pixels": args.min_pixels,
            "min_brightness": args.min_brightness,
            "min_area": args.min_area,
            "min_score": args.score,
            "sky_ratio": args.sky_ratio,
            "color_weight": args.color_weight,
            "use_half_size": not args.full_res,
        },
        prefix=args.prefix,
        save_marked=args.save_marked,
        output_format=args.format,
        progress_cb=cb,
    )

    print(f"[✓] 完成: 处理 {result['processed']} 张，命中 {result['hits']} 张，复制 {result['copied']} 张")
    if result["hits"] == 0:
        print("[?] 未检测到闪电，建议降低阈值: --threshold 25 --min-pixels 200 --score 0.3")


if __name__ == "__main__":
    main()
