#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
视频拆帧检测驱动 —— 流式读取视频，对抽出的帧按筛图功能检测，只把命中帧落盘

支持：
  * function=lightning / meteor，复用各自检测器的"内存帧"核心（analyze_rgb / analyze_frames）
  * 抽帧间隔 frame_step（每 N 帧取 1 帧）；帧数过多时自动加大间隔
  * 选区（归一化）、标记图、取消、进度事件
  * 输出：命中帧原图 + 可选 marked/ 标记图；文件名带原始帧号（便于回溯到视频位置）

内存占用恒定：只保留前一帧（或流星滑动窗口的最近 N 帧灰度）。
"""

from __future__ import annotations

from collections import deque
from pathlib import Path
from typing import Callable, Optional, Sequence

import cv2
import numpy as np

from lightning_detector import draw_marks

# 单次视频检测最多分析的帧数（超出自动加大抽帧间隔）
MAX_FRAMES = 20000


def _build_detector(function: str, params: dict, video_hw: Optional[tuple] = None):
    if function == "meteor":
        from meteor_detector import MeteorDetector
        # 视频模式开启边缘伪影过滤：排除贴边轮廓 + 忽略画面底部 ~1% 条带
        bottom_band = 0
        if video_hw is not None:
            bottom_band = max(2, int(video_hw[0] * 0.01))
        return MeteorDetector(
            diff_threshold=params["diff_threshold"],
            min_area=params["min_area"],
            min_ratio=params["min_ratio"],
            max_ratio=params["max_ratio"],
            min_score=params["min_score"],
            window_size=params["window_size"],
            use_half_size=params["use_half_size"],
            no_auto_bright=params["no_auto_bright"],
            drop_border=True,
            bottom_band=bottom_band,
        )
    from lightning_detector import LightningDetector
    return LightningDetector(
        diff_threshold=params["diff_threshold"],
        min_bright_pixels=params["min_bright_pixels"],
        sky_ratio=params["sky_ratio"],
        color_weight=params["color_weight"],
        min_score=params["min_score"],
        min_brightness=params["min_brightness"],
        min_area=params["min_area"],
        use_half_size=params["use_half_size"],
        no_auto_bright=params["no_auto_bright"],
    )


def _merge_params(function: str, raw: Optional[dict]) -> dict:
    if function == "meteor":
        from meteor_detector import merge_params
        return merge_params(raw)
    from lightning_detector import merge_params
    return merge_params(raw)


def _half_size(rgb: np.ndarray, use_half_size: bool) -> np.ndarray:
    """与图片检测一致：超 1024 且开启半分辨率时缩小"""
    if use_half_size and max(rgb.shape[:2]) > 1024:
        h, w = rgb.shape[:2]
        return cv2.resize(rgb, (w // 2, h // 2), interpolation=cv2.INTER_AREA)
    return rgb


# ---------------------------------------------------------------------------
# 视频读取器（多后端回退，提升编码兼容性）
# ---------------------------------------------------------------------------
class _CvReader:
    """cv2.VideoCapture 封装：默认 FFmpeg 后端，失败时回退 Media Foundation（Win 系统编解码器）"""

    def __init__(self, path: str):
        self.cap = None
        self.backend = ""
        for backend, name in ((None, "ffmpeg"), (cv2.CAP_MSMF, "msmf")):
            try:
                cap = cv2.VideoCapture(str(path)) if backend is None else cv2.VideoCapture(str(path), backend)
            except Exception:
                continue
            if cap.isOpened():
                self.cap = cap
                self.backend = name
                break

    def opened(self) -> bool:
        return self.cap is not None

    def read(self):
        return self.cap.read()

    def release(self):
        if self.cap is not None:
            self.cap.release()

    def info(self) -> dict:
        try:
            codec = int(self.cap.get(cv2.CAP_PROP_FOURCC) or 0)
            codec_str = "".join(chr((codec >> 8 * i) & 0xFF) for i in range(4))
        except Exception:
            codec_str = "?"
        return {
            "backend": self.backend,
            "codec": codec_str,
            "width": int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0),
            "height": int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0),
            "fps": self.cap.get(cv2.CAP_PROP_FPS) or 0.0,
            "total": int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0),
        }


class _ImageioReader:
    """imageio-ffmpeg 回退：自带完整 FFmpeg，可解码 HEVC/AV1 等（帧为 RGB）"""

    def __init__(self, path: str):
        import imageio.v2 as iio
        self.reader = iio.get_reader(path, plugin="ffmpeg", format="FFMPEG")
        self.backend = "imageio"
        meta = dict(self.reader.get_meta_data())
        self._info = {
            "backend": self.backend,
            "codec": str(meta.get("codec") or "?"),
            "width": int(meta.get("size")[0] if meta.get("size") else 0),
            "height": int(meta.get("size")[1] if meta.get("size") else 0),
            "fps": float(meta.get("fps") or 0.0),
            "total": 0,  # imageio 帧数探测不可靠
        }
        self._it = iter(self.reader)

    def opened(self) -> bool:
        return True

    def read(self):
        try:
            rgb = next(self._it)  # RGB uint8
            if rgb.dtype != np.uint8:
                rgb = np.clip(rgb, 0, 255).astype(np.uint8)
            bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
            return True, bgr
        except StopIteration:
            return False, None

    def release(self):
        try:
            self.reader.close()
        except Exception:
            pass

    def info(self) -> dict:
        return dict(self._info)


def _open_video(path: str) -> _CvReader:
    """按 cv2(ffmpeg) -> cv2(msmf) -> imageio-ffmpeg 顺序尝试打开"""
    r = _CvReader(path)
    if r.opened():
        return r
    try:
        return _ImageioReader(path)
    except Exception:
        raise RuntimeError(
            f"无法打开视频（编码可能不受支持）: {path}\n"
            "支持的常见格式：mp4/mov/avi/mkv/webm/wmv/ts 中的 H.264、H.265/HEVC、MPEG-4、VP8/VP9、AV1、MJPG 等。\n"
            "若仍打不开，请先用格式转换工具把视频转为 H.264 的 mp4。"
        )


def video_detect(
    video_path: str,
    output_dir: str,
    params: Optional[dict] = None,
    function: str = "lightning",
    regions: Optional[Sequence[dict]] = None,
    prefix: str = "frame",
    save_marked: bool = False,
    output_format: str = "jpg",
    frame_step: int = 1,
    progress_cb: Optional[Callable[[int, int, int, str], None]] = None,
    cancel_event=None,
    log_cb: Optional[Callable[[str], None]] = None,
) -> dict:
    """
    视频拆帧检测：
      1. 流式读取视频（cv2 FFmpeg/MediaFoundation 或 imageio 回退），按 frame_step 抽帧
      2. 逐帧调用对应检测器的内存帧核心（diff 用前一帧；流星 window 用最近窗口）
      3. 命中帧保存为图片（原帧 + 可选标记图），文件名带原始帧号
    返回: {total, processed, hits, copied, cancelled, step, results:[命中帧]}
    """
    p = _merge_params(function, params)

    reader = _open_video(video_path)
    info = reader.info()
    total = info["total"]
    fps = info["fps"]
    if log_cb:
        log_cb(
            f"视频信息: {Path(video_path).name} | {info['width']}x{info['height']} | "
            f"{fps:.1f}fps | {total} 帧 | 编码 {info['codec']} | 解码后端 {info['backend']}"
        )
    video_hw = (info["height"], info["width"]) if info["height"] else None
    det = _build_detector(function, p, video_hw)

    # 抽帧间隔：期望帧数超上限时自动加大（并让调用方知道实际用的间隔）
    step = max(1, int(frame_step or 1))
    if total and total / step > MAX_FRAMES:
        step = int(np.ceil(total / MAX_FRAMES))
    # 进度条分母 = 实际将分析的帧数（非视频原始帧数，否则抽帧时进度到不了 100%）
    expected = int(np.ceil(total / step)) if total else 0

    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    mark_dir = out_dir / "marked"
    mark_dir.mkdir(parents=True, exist_ok=True)

    fmt = output_format if output_format in ("jpg", "png") else "jpg"
    ext = "." + fmt
    enc = ".jpg" if fmt == "jpg" else ".png"

    processed = 0
    hits = 0
    copied = 0
    results: list = []
    frame_idx = 0
    prev = None            # lightning: 上一抽帧 RGB；meteor: 上一抽帧灰度
    window: Optional[deque] = deque(maxlen=p.get("window_size", 21)) if function == "meteor" else None

    # 飞机过滤（仅流星检测）：命中帧先缓冲，流式结束后统一跨帧关联再落盘
    aircraft_filter = function == "meteor" and bool(p.get("aircraft_filter"))
    frame_lines_all: list = []      # 每处理帧的候选线（与处理顺序对齐）
    hit_records: list = []          # {seq, frame_idx, bgr_bytes, score}

    while True:
        if cancel_event is not None and cancel_event.is_set():
            break
        ok, frame_bgr = reader.read()
        if not ok:
            break
        frame_idx += 1
        if (frame_idx - 1) % step != 0:
            continue  # 抽帧：跳过

        rgb = _half_size(cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB), p["use_half_size"])

        if function == "meteor":
            gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY).astype(np.float32)
            window_frames = None
            center_idx = None
            if p["mode"] == "window":
                window.append(gray)
                if len(window) >= p["window_size"]:
                    window_frames = list(window)
                    center_idx = len(window_frames) - 1  # 当前帧在窗口末尾
            res = det.analyze_frames(
                gray, prev_gray=prev if window_frames is None else None,
                window_frames=window_frames, center_idx=center_idx, regions=regions,
            )
            prev = gray
            frame_lines_all.append(res.get("lines") or [])
        else:
            res = det.analyze_rgb(rgb, img_prev=prev, regions=regions)
            prev = rgb

        processed += 1
        if res["hit"]:
            hits += 1
            if aircraft_filter:
                ok_enc, buf = cv2.imencode(".jpg", frame_bgr, [cv2.IMWRITE_JPEG_QUALITY, 92])
                hit_records.append({
                    "seq": len(frame_lines_all) - 1,
                    "frame_idx": frame_idx,
                    "bgr_bytes": buf.tobytes() if ok_enc else None,
                    "score": res["score"],
                })
            else:
                name = f"{prefix}_{hits:03d}_f{frame_idx:06d}{ext}"
                dst = out_dir / name
                cv2.imencode(enc, frame_bgr)[1].tofile(str(dst))
                marked = None
                if save_marked:
                    marked_img = draw_marks(rgb, res["boxes"], res["score"])
                    marked_path = mark_dir / f"{dst.stem}_marked.jpg"
                    cv2.imencode(".jpg", cv2.cvtColor(marked_img, cv2.COLOR_RGB2BGR))[1].tofile(str(marked_path))
                    marked = str(marked_path)
                copied += 1
                results.append({
                    "frame": frame_idx,
                    "name": name,
                    "hit": True,
                    "score": res["score"],
                    "dst": str(dst),
                    "marked": marked,
                })

        if progress_cb:
            progress_cb(processed, expected, hits, f"帧 {frame_idx}")

    reader.release()
    if progress_cb:
        progress_cb(processed, expected, hits, "")

    # 流式结束：跨帧轨迹关联，丢弃飞机/卫星轨迹的命中帧
    if aircraft_filter:
        from meteor_detector import apply_aircraft_filter, rebuild_from_kept
        keep = apply_aircraft_filter(frame_lines_all, p)
        kept_no = 0
        for rec in hit_records:
            if rec["bgr_bytes"] is None:
                continue
            rebuilt = rebuild_from_kept(frame_lines_all[rec["seq"]], keep, rec["seq"])
            if rebuilt is None:
                continue  # 该帧属于飞机轨迹，丢弃
            kept_no += 1
            name = f"{prefix}_{kept_no:03d}_f{rec['frame_idx']:06d}{ext}"
            dst = out_dir / name
            dst.write_bytes(rec["bgr_bytes"])
            marked = None
            if save_marked:
                frame_bgr = cv2.imdecode(np.frombuffer(rec["bgr_bytes"], np.uint8), cv2.IMREAD_COLOR)
                marked_img = draw_marks(cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB), rebuilt["boxes"], rebuilt["score"])
                marked_path = mark_dir / f"{dst.stem}_marked.jpg"
                cv2.imencode(".jpg", cv2.cvtColor(marked_img, cv2.COLOR_RGB2BGR))[1].tofile(str(marked_path))
                marked = str(marked_path)
            copied += 1
            results.append({
                "frame": rec["frame_idx"],
                "name": name,
                "hit": True,
                "score": rebuilt["score"],
                "dst": str(dst),
                "marked": marked,
            })
        hits = kept_no

    return {
        "total": total,
        "processed": processed,
        "hits": hits,
        "copied": copied,
        "cancelled": cancel_event is not None and cancel_event.is_set(),
        "step": step,
        "results": results,
    }
