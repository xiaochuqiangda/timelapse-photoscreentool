@echo off
chcp 65001 >nul
title 延时摄影筛图工具
cd /d "%~dp0"

REM 指定算法源码目录（含 service.py）
set "LIGHTNING_PYTHON_DIR=%~dp0python"

start "" "%~dp0lightning-picker.exe"
exit /b 0
